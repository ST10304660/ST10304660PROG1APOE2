/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.st10304660poe2lebonepaballomnisiprog1a;

/**
 *
 * @author paballolenkoane
 */
public class ST10304660POE2LEBONEPABALLOMNISIPROG1A {

     public static void main(String[] args) {
  
        Login login1 = new Login();

        login1.menu();
    }
}//Farrell, J. (2022). Java Programming. Cengage Learning.


