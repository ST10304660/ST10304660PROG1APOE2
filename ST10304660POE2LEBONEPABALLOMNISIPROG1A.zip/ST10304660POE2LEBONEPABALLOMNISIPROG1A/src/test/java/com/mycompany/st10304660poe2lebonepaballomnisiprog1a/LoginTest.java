/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.st10304660poe2lebonepaballomnisiprog1a;

import java.lang.reflect.Method;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 *
 * @author paballolenkoane
 */
public class LoginTest {
    
    public LoginTest() {
    }

    private Login login;

    @BeforeEach
    void setUp() {
        login = new Login();
    }
    
    @Test
    public void testCheckUsernameFormatCorrect(){
        Login login1 = new Login();
        String testData = "Kyl_1";
        assertTrue(login1.validateUsername(testData), "Username is correctly formatted.");
    }
    
    @Test
    public void testCheckUsernameFormatIncorrect(){
        Login login1 = new Login();
        String testData = "Kyle!!!!!!";
        assertFalse(login1.validateUsername(testData), "Username is incorrectly formatted.");
    }
    
    @Test
    public void testCheckPasswordComplexityCorrect(){
        Login login1 = new Login();
        String testData = "Ch&&sec@k99!";
        assertTrue(login1.validatePassword(testData), "Password complexity is correct.");
    }
    
    @Test
    public void testCheckPasswordComplexityIncorrect(){
        Login login1 = new Login();
        String testData = "password";
        assertFalse(login1.validatePassword(testData), "Password complexity is incorrect.");
    }
    
    @Test
    void testGenerateTaskID() throws Exception {
        // Access the private method generateTaskID using reflection
        Method method = Login.class.getDeclaredMethod("generateTaskID", String.class, int.class, String.class);
        method.setAccessible(true);

        // Define test cases
        String taskName1 = "TaskOne";
        int taskNumber1 = 1;
        String lastName1 = "Doe";

        String taskName2 = "To";
        int taskNumber2 = 2;
        String lastName2 = "Smith";

        String taskName3 = "ABC";
        int taskNumber3 = 3;
        String lastName3 = "Johnson";

        // Expected results
        String expectedID1 = "TAS:1:DOE";
        String expectedID2 = "TO:2:ITH";
        String expectedID3 = "ABC:3:SON";

        // Invoke the method and check the results
        String actualID1 = (String) method.invoke(login, taskName1, taskNumber1, lastName1);
        String actualID2 = (String) method.invoke(login, taskName2, taskNumber2, lastName2);
        String actualID3 = (String) method.invoke(login, taskName3, taskNumber3, lastName3);

        // Assert the results
        assertEquals(expectedID1, actualID1);
        assertEquals(expectedID2, actualID2);
        assertEquals(expectedID3, actualID3);
    }
    
     @Test
    void testShowTaskStatus_WithTasks() {
        // Create a new Login instance
        Login login1 = new Login();
        
        // Prepare test data: tasks and their statuses
        List<Task> tasksToDo = new ArrayList<>();
        tasksToDo.add(new Task("Task 1", "Description 1", "To Do", "Author 1", 2));
        tasksToDo.add(new Task("Task 2", "Description 2", "To Do", "Author 2", 3));
        tasksToDo.add(new Task("Task 3", "Description 3", "To Do", "Author 3", 4));
        
        // Set the test data in the Login instance
        login1.getTaskStatusMap().put("To Do", tasksToDo);
        
        // Call the method under test
        String result = login1.showTaskStatus("To Do");
        
        // Prepare the expected result string
        StringBuilder expected = new StringBuilder("Tasks in To Do:\n");
        for (Task task : tasksToDo) {
            expected.append(task.getName()).append("\n");
        }
        
        // Assert that the returned task list matches the expected list
        assertEquals(expected.toString(), result);
    }
    
    
    

    

}
    

